package com.example.mylogin;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText ed1, ed2;
    Button bu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        bu = findViewById(R.id.bu);

        // Set button click listener
        bu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get input from EditTexts
                String username = ed1.getText().toString();
                String password = ed2.getText().toString();

                // Validate credentials
                if (username.equals("BoLt") && password.equals("asdfghjkl;'")) {
                    Toast.makeText(MainActivity.this, "Success", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Invalid User", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
