import sqlite3
import smtplib
from flask import Flask, request, jsonify, render_template
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

# Database connection and setup
def get_db_connection():
    conn = sqlite3.connect('chatbot.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS responses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT NOT NULL,
            response TEXT NOT NULL,
            name TEXT NOT NULL
        )
    ''')
    cursor.execute("CREATE TABLE IF NOT EXISTS subscribers (email TEXT PRIMARY KEY)")
    conn.commit()
    return conn

# Load email subscriptions
def load_subscribers():
    conn = get_db_connection()
    cursor = conn.cursor()
    subscribers = [row['email'] for row in cursor.execute("SELECT email FROM subscribers").fetchall()]
    conn.close()
    return subscribers

subscribers = load_subscribers()

# SMTP configuration
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
SMTP_USERNAME = 'trackmyclass.site@gmail.com'
SMTP_PASSWORD = 'oyfludgunwpftizh'  # Use environment variable for security

@app.route('/')
def index():
    return render_template('index.html')

# Handle user queries
@app.route('/query', methods=['POST'])
def query():
    user_query = request.json.get('query')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT response, name FROM responses WHERE question LIKE ?", (f'%{user_query}%',))
    row = cursor.fetchone()
    conn.close()

    if row:
        response = f"{row['response']} - Shared by {row['name']}"
    else:
        response = "Sorry, I don't have an answer to that yet."
    
    return jsonify(response=response)

# Provide suggestions for autocomplete
@app.route('/suggest', methods=['POST'])
def suggest():
    user_input = request.json.get('input')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT question FROM responses WHERE question LIKE ?", (f'%{user_input}%',))
    suggestions = cursor.fetchall()
    conn.close()

    suggestion_list = [row['question'] for row in suggestions]
    return jsonify(suggestions=suggestion_list)

# Update database with new questions and responses
@app.route('/update', methods=['POST'])
def update():
    try:
        if request.is_json:
            # If the request is JSON
            data = request.json
        else:
            # If the request is form-encoded (from HTML forms)
            data = request.form
        
        question = data.get('question')
        response = data.get('response')
        name = data.get('name')
        type_of_entry = data.get('type')

        # Insert new question and response into the database
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO responses (question, response, name) VALUES (?, ?, ?)",
                       (question, response, name))
        conn.commit()
        conn.close()

        # Notify subscribers if it's an event
        if type_of_entry.lower() == 'event':
            notify_subscribers(question, response, name, type_of_entry)

        return jsonify({"message": "Data updated successfully!"})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Handle email subscription
@app.route('/subscribe', methods=['POST'])
def subscribe():
    email = request.json.get('email')

    if email:
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO subscribers (email) VALUES (?)", (email,))
            conn.commit()
            message = "Subscription successful!"
        except sqlite3.IntegrityError:
            message = "Email already subscribed."
        finally:
            conn.close()
        
        return jsonify({'message': message})

    return jsonify({'message': 'Subscription failed!'})

@app.route('/latest_updates', methods=['GET'])
def latest_updates():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT question, response, name FROM responses ORDER BY id DESC LIMIT 5")
    latest_updates = cursor.fetchall()
    conn.close()

    updates_list = [{'question': row['question'], 'response': row['response']} for row in latest_updates]
    return jsonify({'latest_updates': updates_list})


# Notify subscribers via email
def notify_subscribers(question, response, name, type_of_entry):
    subject = 'Event Update on VEC Chatbot'
    body = f"A new {type_of_entry} has been added:\n\nQuestion: {question}\nResponse: {response}\nAnnounced by: {name}"
    
    for subscriber in subscribers:
        try:
            msg = MIMEMultipart()
            msg['From'] = SMTP_USERNAME
            msg['To'] = subscriber
            msg['Subject'] = subject

            msg.attach(MIMEText(body, 'plain'))

            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                server.starttls()
                server.login(SMTP_USERNAME, SMTP_PASSWORD)
                server.send_message(msg)
        except Exception as e:
            print(f"Failed to send email to {subscriber}. Error: {e}")

if __name__ == '__main__':
    app.run(host='192.168.0.103', port=5000, debug=True)
