package com.example.calculator;

import android.app.Activity;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity implements View.OnClickListener {

    Button nine, eig, sev, six, fiv, four, thr, two, one, zero, dot, plus, mins, div, mul, eq, cl;
    EditText et;
    String currentInput = "0";  // Current input string for numbers
    int result = 0;  // Store the result of the calculation
    char lastOperator = ' ';  // Store the last operator used

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Buttons and EditText
        nine = findViewById(R.id.b9);
        eig = findViewById(R.id.b8);
        sev = findViewById(R.id.b7);
        six = findViewById(R.id.b6);
        fiv = findViewById(R.id.b5);
        four = findViewById(R.id.b4);
        thr = findViewById(R.id.b3);
        two = findViewById(R.id.b2);
        one = findViewById(R.id.b1);
        zero = findViewById(R.id.b0);
        dot = findViewById(R.id.bd);
        plus = findViewById(R.id.bpl);
        mins = findViewById(R.id.bmin);
        div = findViewById(R.id.bdiv);
        mul = findViewById(R.id.bmul);
        eq = findViewById(R.id.beq);
        cl = findViewById(R.id.bcl);
        et = findViewById(R.id.tv);

        // Set OnClickListener for Buttons
        nine.setOnClickListener(this);
        eig.setOnClickListener(this);
        sev.setOnClickListener(this);
        six.setOnClickListener(this);
        fiv.setOnClickListener(this);
        four.setOnClickListener(this);
        thr.setOnClickListener(this);
        two.setOnClickListener(this);
        one.setOnClickListener(this);
        zero.setOnClickListener(this);
        dot.setOnClickListener(this);
        plus.setOnClickListener(this);
        mins.setOnClickListener(this);
        div.setOnClickListener(this);
        mul.setOnClickListener(this);
        eq.setOnClickListener(this);
        cl.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if (id == R.id.b0 || id == R.id.b1 || id == R.id.b2 || id == R.id.b3 ||
                id == R.id.b4 || id == R.id.b5 || id == R.id.b6 || id == R.id.b7 ||
                id == R.id.b8 || id == R.id.b9) {
            String inputDigit = ((Button) v).getText().toString();
            if (currentInput.equals("0")) {
                currentInput = inputDigit;  // Start with the clicked number
            } else {
                currentInput += inputDigit;  // Append further digits
            }
            et.setText(currentInput);  // Update the display

            if (lastOperator == '=') {
                result = 0;  // Reset result if "=" was pressed
                lastOperator = ' ';  // Reset operator
            }
        } else if (id == R.id.bpl) {
            compute();  // Perform calculation for addition
            lastOperator = '+';  // Update last operator
        } else if (id == R.id.bmin) {
            compute();  // Perform calculation for subtraction
            lastOperator = '-';  // Update last operator
        } else if (id == R.id.bdiv) {
            compute();  // Perform calculation for division
            lastOperator = '/';  // Update last operator
        } else if (id == R.id.bmul) {
            compute();  // Perform calculation for multiplication
            lastOperator = '*';  // Update last operator
        } else if (id == R.id.beq) {
            compute();  // Perform final calculation
            lastOperator = '=';  // Update last operator
        } else if (id == R.id.bcl) {
            result = 0;  // Reset result to zero
            currentInput = "0";  // Reset input
            lastOperator = ' ';  // Reset operator
            et.setText("0");  // Clear the display
        }
    }

    private void compute() {
        int inputNumber = Integer.parseInt(currentInput);  // Convert current input to integer
        currentInput = "0";  // Reset current input after processing

        switch (lastOperator) {
            case ' ':
                result = inputNumber;  // If no operator, set result to current input
                break;
            case '+':
                result += inputNumber;  // Perform addition
                break;
            case '-':
                result -= inputNumber;  // Perform subtraction
                break;
            case '*':
                result *= inputNumber;  // Perform multiplication
                break;
            case '/':
                if (inputNumber != 0) {
                    result /= inputNumber;  // Perform division, check for divide by zero
                } else {
                    et.setText("Error");  // Display error if division by zero
                    return;
                }
                break;
            case '=':
                break;  // Do nothing on '=' as result is already computed
        }

        et.setText(String.valueOf(result));  // Update the display with the result
    }
}
