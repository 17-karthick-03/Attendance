import sqlite3

def init_db():
    # Connect to the SQLite database (it will create the file if it doesn't exist)
    conn = sqlite3.connect('chatbot.db')
    cursor = conn.cursor()

    # Create the 'responses' table if it doesn't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS responses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        response TEXT NOT NULL,
        name TEXT NOT NULL
    );
    ''')

    # Create the 'subscribers' table if it doesn't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS subscribers (
        email TEXT PRIMARY KEY
    );
    ''')

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

    print("Database initialized successfully.")

if __name__ == '__main__':
    init_db()
