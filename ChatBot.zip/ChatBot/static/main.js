function sendQuery() {
    const query = document.getElementById('queryInput').value;
    if (query.trim() === "") return;

    // Display user's query in the chat
    displayMessage(query, 'user-message');

    fetch('/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: query })
    })
    .then(response => response.json())
    .then(data => {
        displayMessage(data.response, 'chatbot-message');
    })
    .catch(error => console.error('Error sending query:', error));

    document.getElementById('queryInput').value = ''; // Clear input box
    document.getElementById('suggestions').style.display = 'none'; // Hide suggestions
}

function showUpdateForm() {
    const updateFormHtml = `
        <div id="updateForm" class="popup">
            <div class="popup-content">
                <span class="close-btn" onclick="closePopup('updateForm')">&times;</span>
                <h2>Update Data</h2>
                <label for="eventOrNews">Choose:</label>
                <select id="eventOrNews">
                    <option value="Event">Event</option>
                    <option value="News">News</option>
                </select>
                <label for="updateQuestion">Question:</label>
                <input type="text" id="updateQuestion" />
                <label for="updateResponse">Response:</label>
                <input type="text" id="updateResponse" />
                <label for="updateName">Your Name:</label>
                <input type="text" id="updateName" />
                <button onclick="submitUpdate()">Submit</button>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', updateFormHtml);
}

function showSubscribeForm() {
    const subscribeFormHtml = `
        <div id="subscribeForm" class="popup">
            <div class="popup-content">
                <span class="close-btn" onclick="closePopup('subscribeForm')">&times;</span>
                <h2>Subscribe</h2>
                <label for="email">Enter your email:</label>
                <input type="email" id="email" />
                <button onclick="submitSubscription()">Subscribe</button>
                <div id="subscriptionStatus" style="display: none; color: green;">Successfully subscribed!</div>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', subscribeFormHtml);
}

function closePopup(id) {
    document.getElementById(id).remove();
}

function submitUpdate() {
    const question = document.getElementById('updateQuestion').value;
    const response = document.getElementById('updateResponse').value;
    const name = document.getElementById('updateName').value;
    const eventOrNews = document.getElementById('eventOrNews').value;

    fetch('/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, response, name, type: eventOrNews })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        closePopup('updateForm');
    })
    .catch(error => console.error('Error updating data:', error));
}

function submitSubscription() {
    const email = document.getElementById('email').value;

    fetch('/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('subscriptionStatus').style.display = 'block';
        } else {
            alert(data.error);
        }
    })
    .catch(error => console.error('Error subscribing:', error));
}

function displayMessage(message, className) {
    const chatContainer = document.getElementById('chatContainer');
    const messageElement = document.createElement('div');
    messageElement.className = `chat-message ${className}`;
    messageElement.innerText = message;
    chatContainer.appendChild(messageElement);
    chatContainer.scrollTop = chatContainer.scrollHeight; // Scroll to bottom
}

function toggleMenu() {
    const menuOptions = document.getElementById('menuOptions');
    if (menuOptions.style.display === 'block') {
        menuOptions.style.display = 'none';
    } else {
        menuOptions.style.display = 'block';
    }
}

function showSuggestions() {
    const input = document.getElementById('queryInput').value;
    const suggestionsBox = document.getElementById('suggestions');

    if (input.trim() === "") {
        suggestionsBox.style.display = 'none';
        return;
    }

    fetch('/suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: input })
    })
    .then(response => response.json())
    .then(data => {
        suggestionsBox.innerHTML = '';
        if (data.suggestions.length > 0) {
            suggestionsBox.style.display = 'block';
            data.suggestions.forEach(suggestion => {
                const suggestionElement = document.createElement('div');
                suggestionElement.className = 'suggestion';
                suggestionElement.innerText = suggestion;
                suggestionElement.onclick = () => {
                    document.getElementById('queryInput').value = suggestion;
                    suggestionsBox.style.display = 'none';
                };
                suggestionsBox.appendChild(suggestionElement);
            });
        } else {
            suggestionsBox.style.display = 'none';
        }
    })
    .catch(error => console.error('Error fetching suggestions:', error));
}
